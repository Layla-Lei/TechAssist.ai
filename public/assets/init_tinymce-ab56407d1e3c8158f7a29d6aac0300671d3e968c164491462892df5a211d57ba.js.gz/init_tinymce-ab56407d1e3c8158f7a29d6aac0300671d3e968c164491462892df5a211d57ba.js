document.addEventListener('DOMContentLoaded', function() {
    tinymce.init({
      selector: 'textarea.tinymce',
      // Just a basic setup
    });
  });
  
